<?php
session_start();
include_once('../database.php');
$set_id = $_REQUEST['set_id'];
$name = $_REQUEST['name'];
$score = $_REQUEST['score'];
$sql = "insert into user_score(int_set_id,name,score) values('$set_id','$name','$score');";
$status = $conn->query($sql);
if(!$status){	echo "error";}
?>
