<?php
session_start();
include_once("../database.php");
$questions_call = "curl https://opentdb.com/api.php?amount=10";
$questions = exec($questions_call);
$question_array = json_decode($questions, true);
$sql = "select max(question_set) as question_set_sequence from question_details;";
$results = $conn->query($sql);
foreach($results as $result)
{
	$count = $result['question_set_sequence'];
	if($count == null){	$count = 1;}else{	$count += 1;}
}
$set_no = $count;
if($question_array['response_code'] == 0)
{
	$datas = $question_array['results'];
	for($i=0;$i<count($datas);$i++)
	{
		$category = $datas[$i]['category'];
		$type = $datas[$i]['type'];
		$difficulty = $datas[$i]['difficulty'];
		$question = $datas[$i]['question'];
		$correct_answer = $datas[$i]['correct_answer'];
		$incorrect_answers = $datas[$i]['incorrect_answers'];
		foreach($incorrect_answers as $incorrect_answer)
		{
			$answers .= $incorrect_answer."|";
		}
		$final_incorrect_answer = substr($answers,0,strlen($answers)-1);;
		$answers = "";
		$insert_questions = "insert into question_details(question_set,category,type,difficulty,question,incorrect_answer,correct_answer) values($set_no,'$category','$type','$difficulty','$question','$final_incorrect_answer','$correct_answer');";
		$status = $conn->query($insert_questions);
	}
//	$get_questions = "select question_set,category,type,difficulty,question,CONCAT_WS('|',incorrect_answer,correct_answer) as answers,correct_answer from question_details where question_set = 2 and status = 'active';";
	$get_questions = "select question_set,category,type,difficulty,question,CONCAT_WS('|',incorrect_answer,correct_answer) as answers,correct_answer from question_details where question_set = $set_no and status = 'active';";
	$values = $conn->query($get_questions);
	if(mysqli_num_rows($values)>0)
	{
		while($rows = mysqli_fetch_assoc($values))	{	$data[] = $rows;	}
		print(json_encode($data));
	}else{	echo 0;}
}else{	echo 0;}
?>
