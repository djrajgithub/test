<?php
$conn = mysqli_connect('localhost','root','King#6060','fyntune');
?>
