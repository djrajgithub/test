$(document).ready(function()
{
	$.ajax({
		url:'ajax/get_scores.php',
		method:'GET',
		success:function(results)
		{
			if(results == 0){	alert("No records found");}
			else
			{
				$("#score_tablediv").html(results);
			}
		}})
})
