$(document).ready(function()
{
	$("#login").on('click',function()
	{
		var email = $("#username").val();var password = $("#password").val();
		if(!email || !isValidEmailAddress(email)){	alert("Enter valid email id");}
		else if(!password){	alert("Enter Valid Password");}
		else
		{
			$.ajax({
				url:'ajax/login.php',
				data:{email:email,password:password},
				method:'POST',
				success:function(data)
				{
					if(data == 0){	alert("Invalid username or password");}
					else{	window.location.assign('home.php');}
				}
			})
		}
	})

	function isValidEmailAddress(emailAddress)
	{
        	var pattern = new RegExp(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/);
	        return pattern.test(emailAddress);
	};

})
