<?php
session_start();
include_once("../../database.php");
$sql = "select name,score from user_score where status = 'active'";
$results = $conn->query($sql);

while ($row = mysqli_fetch_assoc($results))
{if (empty($columns)){	$columns = array_keys($row);	}	$resultset[] = $row;}

if(count($resultset) == 0){    echo 0;	}
else
{?>
<html>
	<head><link rel="stylesheet" type="text/css" href="../../css/datatables.css"></head>
<body>
<table id="score_datatable" class="table table-striped table-bordered dataTable no-footer">
<thead>
<tr>
<?php foreach ($columns as $k => $column_name ) : ?>
<th> <?php echo strtoupper($column_name);?> </th>
<?php endforeach; ?>
</tr>
</thead>
<tbody>
<?php
foreach($resultset as $index => $row)
{
$column_counter =0;
?><tr><?php
for ($i=0; $i < count($columns); $i++):?>
<td> <?php echo $row[$columns[$column_counter++]]; ?>   </td>
<?php endfor;?>
</tr>
<?php } ?>
</tbody>
</table>
</body>
<script>
$(function(){$("#score_datatable").dataTable({        "lengthMenu": [ [ -1], ["All"] ]        });})
</script>
</html>
<?php }

/*if(mysqli_num_rows($results)>0)
{
	while($rows = mysqli_fetch_assoc($results))
	{	$data[] = $rows;	}
	print(json_encode($data));
}else{	echo 0;}*/
?>
