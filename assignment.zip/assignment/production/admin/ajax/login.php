<?php
include_once('../../database.php');
session_start();
$email = $_REQUEST['email'];
$password = md5($_REQUEST['password']);
$sql = "select int_user_id,role from user_master where email = '$email' and password = '$password' and status = 'active'";
$results = $conn->query($sql);
if(mysqli_num_rows($results)>0)
{
	foreach($results as $result){	$int_user_id = $result['int_user_id'];	$role = $result['role'];}
	$_SESSION['int_user_id'] = base64_encode($int_user_id);
	$_SESSION['role'] = base64_encode($role);
	echo 1;	
}else {	echo 0;}
?>
