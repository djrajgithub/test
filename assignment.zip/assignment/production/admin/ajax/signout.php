<?php
session_start();
session_destroy();
unset($_SESSION['int_user_id']);
header('location:../');
?>
