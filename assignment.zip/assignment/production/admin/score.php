<?php include_once('header.php');?>
<div class="x_panel">
<div id="score_tablediv"></div>
</div>
<?php include_once('footer.php');?>
<script src="js/score.js"></script>
<script src="js/datatables.js"></script>

