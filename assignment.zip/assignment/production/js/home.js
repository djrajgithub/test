$(document).ready(function()
{	
	$.ajax({
		url:'ajax/get_questions.php',
		method:'POST',
		success:function(results)
		{
			if(results == 0){	alert("No data found");}
			else
			{
				var data = JSON.parse(results);
				var div_details = "";
				var counter = 1;var count;
				for(var sets in data)
				{
					count = counter++;					
					div_details += "<label>"+count+" &emsp;";
					div_details += data[sets]['question'];
					div_details += "</label><br>";
					var answers = data[sets]['answers'].split('|');
					var final_answers = getRandom(answers,answers.length);
					div_details += '<p class="answers_class"> Ans:- &emsp;';
					for(var i=0;i<final_answers.length;i++)
					{
						div_details += '<input type="radio" id="'+count+final_answers[i]+'" name="'+count+'" ';
						div_details += ' value="'+final_answers[i]+'">';
						div_details += '&nbsp;&nbsp;<label for="'+count+final_answers[i]+'">'+final_answers[i]+'</label>&emsp;';
					}
					div_details += "</p>";
					div_details += '<input type="hidden" id="'+count+'" value="'+data[sets]['correct_answer']+'">';
					div_details += '<input type="hidden" id="set_id" value="'+data[sets]['question_set']+'">';
				}
				div_details += '<input type="text" id="name" placeholder="Enter Your Name" class="form-control col-sm-4">';
				div_details += '<input type="button" value="Submit" id="submit" class="form-control btn btn-success col-sm-2">';
/*				div_details += '<div class="ln_solid"><div class="form-group"><div class="col-md-6 offset-md-3">';
				div_details += '<input type="button" id="submit" value="Submit" class="btn btn-primary"></div></div>';*/
				$("#question_sets").html(div_details);
			}
		}
	})

	$(document).on('click','#submit',function()
	{
		var length = $(".answers_class").length;
		var answer_score = 0;
		var name = $("#name").val();	var set_id = $("#set_id").val(); var answered = 0;
		if(!name){	alert("Please enter your name");}
		else
		{
			for(var i=1;i<=length;i++)
			{
				var value = $("input[name='"+i+"']:checked"). val();
				var correct_answer = $("#"+i).val();
				if(value != undefined){	answered++;}
				if(value === correct_answer){	answer_score ++;}
			}
			if(answered != length){   alert("Please answer all questions");}
			else
			{
				$.ajax({
					url:'ajax/save_score.php',
					data:{set_id:set_id,name:name,score:answer_score},
					method:'POST',
					success:function(response)
					{
						if(response == "error"){	alert("Error while storing answers");}
						else
						{
							$("#score").text('Your Score is '+answer_score);
							$("#question_sets").css('display','none');
							$("#score_div").css('display','block');
						}
					}
				})
			}
		}
	})

	function getRandom(arr, n) 
	{
		var result = new Array(n),
		len = arr.length,
		taken = new Array(len);
		while (n--) 
		{
			var x = Math.floor(Math.random() * len);
			result[n] = arr[x in taken ? taken[x] : x];
			taken[x] = --len in taken ? taken[len] : len;
		}
		return result;
	}
})
